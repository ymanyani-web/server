<?php
echo $_POST['nom'];
    try
    {
        $bdd = new PDO('mysql:host=localhost;dbname=ellariasystems;charset=utf8', 'root', 'root');
    }
    catch (Exception $e)
    {
        die('Erreur : ' . $e->getMessage());
    }
    $req = $bdd->prepare('INSERT INTO intervention(nom_intervenant, lieu_intervention, `date`, date_from, date_to, intervention ) VALUES(:nom, :lieu, :dd, :dd_from, :dd_to, :inn)');
    $req->execute(array(
        'nom'=> $_POST['nom'],
        'lieu'=> $_POST['lieu'],
        'dd'=> $_POST['datee'],
        'dd_from'=> $_POST['date_from'],
        'dd_to'=> $_POST['date_to'],
        'inn'=> $_POST['intervention'],
    ));
?>