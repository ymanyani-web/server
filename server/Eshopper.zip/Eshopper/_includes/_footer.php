<footer>
            <div id="footer-top">
                <div class="footer-text">
                    <h2 id="logo-footer">Y•<span>Commerce</span></h2>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                    </p>
                </div>
                <div class="footer-text">
                    <h3>Latest Tweets</h3>
                </div>
                <div class="footer-text">
                    <h3>Recent Posts</h3>
                    <p><strong>Publish What You Learn</strong></p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
                    <p><strong>Redisigning With Persobnality</strong></p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt, sed do eiusmod tempor incididunt</p>
                </div>
                <div class="footer-text gallery-bottom">
                    <h3>Photo Stream</h3>
                    <img src="./images/projects/project_01.jpg" alt="Project 1" />
                    <img src="./images/projects/project_02.jpg" alt="Project 2" />
                    <img src="./images/projects/project_03.jpg" alt="Project 3" />
                    <img src="./images/projects/project_04.jpg" alt="Project 4" />
                    <img src="./images/projects/project_04.jpg" alt="Project 1" />
                    <img src="./images/projects/project_03.jpg" alt="Project 2" />
                    <img src="./images/projects/project_02.jpg" alt="Project 3" />
                    <img src="./images/projects/project_01.jpg" alt="Project 4" />
                </div>
            </div>
            <div id="footer-bottom">
                <div id="credits">
                        <p> &copy; Revision Copyright - All Rights reserved</p>
                        <p>Legal Notice</p>
                        <p>Terms and Conditions</p>
                </div>
                <div id="social">
                    <a href="#" class="fa fa-facebook-official"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                    <a href="#" class="fa fa-instagram"></a>
                </div>
            </div>
        </footer>

    </div>
</body>
</html>