<?php
$DB_NAME = "camagru";
$DB_DSN = "mysql:host=localhost;dbname=".$DB_NAME;
$DB_DSN_LIGHT = "localhost";
$DB_USER = "camagru";
$DB_PASSWORD = "camagru";
?>
